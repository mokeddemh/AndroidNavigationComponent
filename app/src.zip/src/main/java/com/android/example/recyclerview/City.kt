package com.android.example.recyclerview

/**
 * Created by hakim on 3/11/18.
 */

// The entity with default constructor

data class City(var listImage:Int,
                var detailImage:Int,
                var name:String,
                var touristNumber:String,
                    var places:String,
                var description:String)